<?php

    session_start();
    require_once('includes/hybridauth/src/autoload.php');

    if(isset($_SESSION["mail"]))
    {
        header("location:http://localhost/demo/auth22/loginform.php");
    }


// we are using these built in functions of composer

    use Hybridauth\Exception\Exception;
    use Hybridauth\Hybridauth;
    use Hybridauth\HttpClient;

    // this is the end of built in function of composer

    if($_GET["keyword"] == "google" || $_GET["keyword"] == "Dribbble")
    {
        $provider = $_GET["keyword"];
        $config = [
            'callback' => "http://localhost/demo/auth22/backend.php?request=$provider",
            'providers' => [
                'Google' => [
                    'enabled' => true,
                    'keys' => [
                        'id' => 'insert id',
                        'secret' => 'insert key',
                    ]
                ],
                'Dribbble' => [
                    'enabled' => true,
                    'keys' => [
                        'id' => 'insert id',
                        'secret' => 'insert key',
                    ]
                ]
            ]
        ];
    }

    else
    {
        HttpClient\Util::redirect('http://localhost/demo/auth22/frontend.php');
    }

    try
    {

      // buit it functions of composer php

        $hybridauth = new Hybridauth($config);

        $hybridauth->authenticate(ucfirst($provider));

        $adapters = $hybridauth->getConnectedAdapters();

        $userInfo = $adapters[ucfirst($provider)]->getUserProfile();

      // variables which contain user data

        $emailuser = $userInfo->email;
        $photo = $userInfo->photoURL;

        $_SESSION["mail"] = $emailuser;
        $_SESSION['photo'] = $photo;

        /**
        * Redirects user to home page after successful login attemp
        */
        HttpClient\Util::redirect('http://localhost/demo/auth22/frontend.php');

    }
    catch (Exception $error)
    {
        echo $error->getMessage();
    }
?>
